#pragma once
#include <iostream>
using namespace std;


//declare 2 funcs definition in header w/o body

// declare array para with pointer and type of data
int findfMaxNumb(int* array, int ArrSize); 


void testFindMaxNumb();
