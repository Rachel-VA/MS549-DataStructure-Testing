/*
Rachael Savage
MS549-Data Structure and Testing
Dr. Jill Coddington
11/10/2024
*/

/*
This project is a demonstration of practicing using pointer and recursion in a useful way in a program that find a max number in a array.
Plus, applying 2 simple testing methods: 
1. Performance testing using time clock time "chrono" lib
2. simplified unit testin using "cassert" lib

*/

/****** NOTE: 
* POINTER:a variable that store a memory address
* Step 1: declare a var with a data type
* Step 2: create a pointer var to hold the address declared by adding & before the var
* Step 3: To modify the value that stored in the address that the pointer is pointing to, using DEREFERENCE operator by adding * before pointer and assign a new value
* ----------------------------------------------------------------
* 
* RECURION: a func that calls itself repeatedly to solve a tree-like problem by breaking it down smaller steps until it reach the defined based case. 
(Ex tree-like: navigate back and forth in a folder and its sub-folders.)
MUST always define a base case to end it.
Else, it'll run indefinitely, resulting stack over
*/

#include <iostream>
using namespace std;
#include "FindMaxNumber.h"
#include <chrono>
#include <cstdlib>  //for randome lib
#include <ctime> //for random lib

int main()
{
	//create an array to performce the search 
	//int array[] = { 0,3,5,7,9,10,12,-20,-4,25,91};
	
	//create a large array using loop to generate
	int array[1000]; //set array size
	srand(static_cast<unsigned int>(time(0))); //for the the rand machine
	
	for (int i = 0; i < 1000; i++)
	{
		
		array[i] = rand() % 1000;
	}
	
	auto startCount = chrono::high_resolution_clock::now();
	int maxValue = findfMaxNumb(array, 1000);
	auto endCount = chrono::high_resolution_clock::now();

	//measure time in miliseconds
	chrono::duration<double, milli> elapsed = endCount - startCount;

	cout << "The max value from the array size  is:  =" << maxValue << "\n The time it took to find the max number is: " << elapsed.count() << " milliseconds.\n" << endl;

	//call the test func
	cout << "The result of testing the arrays: " << endl;
	testFindMaxNumb();




	cout << "\n\n\n\n\n\n\n" << endl;
	return 0;
}