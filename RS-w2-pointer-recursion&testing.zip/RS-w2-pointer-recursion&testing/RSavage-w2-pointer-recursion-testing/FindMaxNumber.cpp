#include "FindMaxNumber.h"
#include <iostream>
using namespace std;
#include<cassert>


//move the func here and add in the body for each 

int findfMaxNumb(int* array, int ArrSize)
{
	//MUST define a base case, just 1 element
	if (ArrSize == 1) return *array;

	//create recursive func
	int maxNumb = findfMaxNumb(array + 1, ArrSize -1); //keep calling
	return (*array > maxNumb) ? *array : maxNumb;
}


void testFindMaxNumb()
{
	int array1[] = { 1,2,3,4,5,6,7,8,9,10};
	assert(findfMaxNumb(array1, 10) == 10);

	int array2[] = { 20,-30,40,51,60,77,18,29,100};
	assert(findfMaxNumb(array2, 9) == 100);

	int array3[] = {1, -5,-15,-25,-35,45,-55,-65,-75,-85,-95,0 };
	assert(findfMaxNumb(array3,12 ) == 45);

	int array4[] = { 200 };
	assert(findfMaxNumb(array4, 1) == 200);

	cout << "Passed all tests! All arrays correctly found the max values." << endl;


}
